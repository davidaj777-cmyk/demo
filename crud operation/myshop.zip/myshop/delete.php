<?php
if( isset($_GET["id"])){
    $id = $_GET["id"];

    $servername = "localhos";
    $username= "root";
    $password = "";
    $database = "myshop";


    $connection = new mysqli($servername,$username,$password,$database);
    
    $sqlc="DELETE FROM clients WHERE id=$id";
    $connection->query($sql);

    $sql ="DELETE FROM clients  WHERE id =$id";
    $connection ->query($sql);


}
?>
